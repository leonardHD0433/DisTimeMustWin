package com.example.urldetection

object ApiKeys {
    const val API_KEY = "Insert API key here"
}